/*
 * Created on Mar 24, 2004
 * $Log: ClassDepend.java,v $
 * Revision 1.2  2004/08/30 21:06:07  bailly
 * cleaned imports
 *
 * Revision 1.1  2004/06/24 14:05:34  bailly
 * integration visualiseur de dependances
 *
 */
package oqube.patchwork;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import oqube.bytes.ClassFile;
import salvo.jesus.graph.DirectedEdgeImpl;
import salvo.jesus.graph.DirectedGraph;
import salvo.jesus.graph.DirectedGraphImpl;
import salvo.jesus.graph.Edge;
import salvo.jesus.graph.Graph;
import salvo.jesus.graph.GraphFactory;
import salvo.jesus.graph.GraphOps;
import salvo.jesus.graph.algorithm.AndGraphFilter;
import salvo.jesus.graph.algorithm.GraphFilter;
import salvo.jesus.graph.algorithm.GraphMorphism;
import salvo.jesus.graph.algorithm.TarjanSCC;
import salvo.jesus.graph.visual.Arrowhead;
import salvo.jesus.graph.visual.DefaultArrowhead;
import salvo.jesus.graph.visual.GraphScrollPane;
import salvo.jesus.graph.visual.VisualEdge;
import salvo.jesus.graph.visual.VisualGraph;
import salvo.jesus.graph.visual.VisualGraphComponentFactory;
import salvo.jesus.graph.visual.VisualGraphComponentManager;
import salvo.jesus.graph.visual.VisualVertex;
import salvo.jesus.graph.visual.layout.SimulatedAnnealingLayout;
import salvo.jesus.graph.visual.print.VisualGraphPrinter;
import fr.lifl.utils.CommandLine;
import fr.lifl.utils.ExtensionFileFilter;

/**
 * This class scans a set of class files and shows interclass relationships in a
 * graphical window.
 * 
 * @author nono
 * @version $Id: ClassDepend.java 1322 2006-09-28 16:32:02Z /CN=nono $
 */
public class ClassDepend extends GraphScrollPane {

  class VertexStat {

    Object v;

    /* # of link to this class */
    int linkTo = 0;

    /* # of link from this class */
    int linkFrom = 0;

    /**
     * @param ov
     */
    public VertexStat(Object ov) {
      v = ov;
    }

  }

  /* list of filtered classes patterns */
  private List filtered;

  /*
   * the set of analyzed classes - this is not the same as classes displayed as
   * analyzed classes may refenrence classes outside of the currently analyzed
   * class set
   */
  private Set analyzed;

  protected boolean implementation = true;

  protected boolean references = true;

  private class TypeFilter implements GraphFilter {

    private Object type;

    TypeFilter(Object type) {
      this.type = type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see salvo.jesus.graph.algorithm.GraphFilter#filter(salvo.jesus.graph.Vertex)
     */
    public boolean filter(Object v) {
      return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see salvo.jesus.graph.algorithm.GraphFilter#filter(salvo.jesus.graph.Edge)
     */
    public boolean filter(Edge e) {
      return !e.getData().equals(type);
    }

  };

  private GraphFilter inhFilter = new TypeFilter("<<inherits>>");

  private GraphFilter depFilter = new TypeFilter("<<uses>>");

  private GraphFilter impFilter = new TypeFilter("<<implements>>");

  /* a filter that excludes referenced classes */
  private GraphFilter refFilter = new GraphFilter() {
    public boolean filter(Object v) {
      if (!analyzed.contains(v))
        return false;
      return true;
    }

    public boolean filter(Edge e) {
      return true;
    }
  };

  private DirectedGraph current;

  private static GraphMorphism packageMorphism = new GraphMorphism() {

    GraphFactory fact;

    /* map from package name to vertex */
    Map /* String, Vertex */
    packmap;

    public void target(Graph target) {
      this.fact = target.getGraphFactory();
      this.packmap = new HashMap();
    }

    /*
     * map class vertices to their corresponding package vertex
     */
    public Object image(Object v) {
      String pname = v.toString();
      /* compute package name */
      if (pname.lastIndexOf('/') > -1)
        pname = ((String) v).substring(0, pname.lastIndexOf('/'));
      return pname;
    }

    public Edge imageOf(Edge e) {
      Object s = image(e.getVertexA());
      Object t = image(e.getVertexB());
      /* return a new edge arrow */
      return fact.createEdgeWith(s, t, e.getData());
    }
  };

  private int minZoom = 1;

  private int maxZoom = 4096;

  private int zoomFactor = 1024;

  private Graph colGraph;

  private boolean collapsed;

  private static List scanList;

  protected boolean packages = false;

  protected boolean dependance = true;

  protected boolean inheritance = true;

  private Object rootv;

  private int curmaxlinks;

  private SimulatedAnnealingLayout layout;

  DirectedGraph graph;

  /* map from names to vertices */
  Map vertexMap;

  static ClassDepend cd;

  /* map from vertices to stats */
  Map statMap = new HashMap();

  private VisualGraphComponentFactory vf;

  ClassDepend() {
    setFont(new Font("sans-serif", Font.PLAIN, 9));
    vf = new VisualGraphComponentFactory() {
      Random rand = new Random();

      public VisualVertex createVisualVertex(Object vertex, VisualGraph graph) {
        // create shape - compute size of text and adjust
        FontMetrics fm = getFontMetrics(getFont());
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, fm.stringWidth(vertex
            .toString()) * 1.2, 2 * fm.getHeight());
        // create VisualVertex
        VisualVertex vv = new VisualVertex(vertex, bounds, Color.BLACK,
            Color.yellow, getFont(), graph);
        vv.setLocation(rand.nextInt(1000), rand.nextInt(1000));
        /* differentiate analyzed classes from referenced classes */
        if (!analyzed.contains(vertex))
          vv.setFillcolor(Color.ORANGE);
        return vv;
      }

      public VisualEdge createVisualEdge(Edge edge, VisualGraph graph) {
        VisualEdge ve = new VisualEdge(edge, graph);
        if (edge.getData().equals("<<inherits>>"))
          ve.setOutlinecolor(Color.ORANGE);
        else if (edge.getData().equals("<<implements>>"))
          ve.setOutlinecolor(Color.RED);
        else if (edge.getData().equals("<<uses>>"))
          ve.setOutlinecolor(Color.black);

        return ve;
      }

      public Arrowhead createArrowhead() {
        return new DefaultArrowhead();
      }
    };
    VisualGraphComponentManager.setFactory(vf);
  }

  private void initData() {
    vertexMap = new HashMap();
    analyzed = new HashSet();
    graph = new DirectedGraphImpl();
    current = graph;
  }

  private void initUI() {
    JFrame frame = new JFrame("Classgraph");
    frame.setJMenuBar(makeMenuBar());
    frame.getContentPane().add(this);
    /* position frame */
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    frame.pack();
    frame
        .setBounds(new Rectangle(100, 100, screen.width / 2, screen.height / 2));
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    updateGraph();
  }

  private void doGraphLayout() {
    /* stop previous l ayout */
    if (layout != null)
      layout.layout();
    layout = new SimulatedAnnealingLayout(getVisualGraph(), true);
    layout.setTemperature(70);
    layout.setCoolFactor(0.01);
    layout.setAttractiveForce(3);
    layout.setExpectedDist(150);
    // layout.setRandomMove(0.02);
    layout.setRepaint(true);
    setGraphLayoutManager(layout);
    layout.layout();
  }

  /**
   * First argument is a directory from which to load classes
   * 
   * @param args
   */
  public static void main(String[] args) throws Exception {
    String clname;
    List lf = new ArrayList();
    /* get options */
    CommandLine cl = new CommandLine();
    cl.addOption('h'); // show inheritance links
    cl.addOption('d'); // show dependance links
    cl.addOption('i'); // show implementation links
    cl.addOption('p'); // show package links
    cl.addOptionMultiple('f'); // filtered classes
    cl.addOptionSingle('v'); // verbosity level
    cl.parseOptions(args);
    /* position arguments */
    if (cl.getArguments().isEmpty())
      cl.getArguments().add(".");

    /* create graph object */
    cd = new ClassDepend();
    cd.inheritance = cl.isSet('h');
    cd.dependance = cl.isSet('d');
    cd.implementation = cl.isSet('i');
    cd.packages = cl.isSet('p');
    cd.filtered = (List) cl.getOption('f').getArgument();
    cd.initData();
    cd.scan(cl.getArguments());
    cd.initUI();
    /* fixed root */
    /*
     * cd.layout.fixVertex( cd.getVisualGraph().getVisualVertex(cd.rootv), 50,
     * 50);
     *//* show */
  }

  /*
   * This method scan given list of files and directories pattenrs and append
   * their content to the processed list of files
   * 
   */
  private void scan(List dirlist) throws FileNotFoundException, IOException {
    List lf = new ArrayList();
    Iterator it = dirlist.iterator();
    /* check command line */
    while (it.hasNext()) {
      File dir = null;
      Object o = it.next();
      if (o instanceof File)
        dir = (File) o;
      else if (o instanceof String)
        dir = new File((String) o);
      if (!dir.isDirectory()) {
        if (!dir.exists()) {
          System.err.println(dir + " is not a directory");
          continue;
        } else
          lf.add(dir);
      } else
        /* recursively enumerate .class files */
        lf.addAll(listFiles(dir));
    }
    /* scan files */
    scanFiles(lf);
    System.err.println("Scanned " + lf.size() + " files");
  }

  private void scanFiles(List lf) throws FileNotFoundException, IOException {
    Iterator it;
    for (it = lf.iterator(); it.hasNext();) {
      File clf = (File) it.next();
      if (!filter(clf.getPath()))
        continue;
      /* read class file and generate ClassFile object */
      InputStream fis = new FileInputStream(clf);
      DataInputStream dis = new DataInputStream(fis);
      ClassFile cf = new ClassFile();
      try {
        cf.read(dis);
        add(cf);
        System.err.println("Checking file " + clf);
      } catch (Throwable e) {
        e.printStackTrace();
        System.err.println("Error adding file " + clf);
      }
      dis.close();
      fis.close();
    }
  }

  /**
   * @return
   */
  private JMenuBar makeMenuBar() {
    JMenuBar menubar = new JMenuBar();
    JMenu menu = new JMenu("File");
    menubar.add(menu);
    JMenuItem item = new JMenuItem("Load");
    menu.add(item);
    item.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        /* prompt for a directory to scan */
        File[] file = null;
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("Scan classes from a directory");
        chooser.setMultiSelectionEnabled(true);
        int returnVal = chooser.showOpenDialog(cd);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
          file = chooser.getSelectedFiles();
        } else
          return;
        /* initialize graph */
        initData();
        try {
          scan(Arrays.asList(file));
          updateGraph();
        } catch (FileNotFoundException e1) {
          JOptionPane.showMessageDialog(cd, "Cannot find a file : " + e1);
        } catch (IOException e1) {
          JOptionPane.showMessageDialog(cd, "Error in scanning files : " + e1);
        }
      }

    });
    item = new JMenuItem("Print");
    menu.add(item);
    item.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        new VisualGraphPrinter(getVisualGraph()).showPrint(getX(), getY());
      }

    });

    item = new JMenuItem("Export");
    item.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        File file = null;
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setDialogTitle("Save dependency graph");
        chooser.setMultiSelectionEnabled(false);
        ExtensionFileFilter filter = new ExtensionFileFilter();
        filter.addExtension("png");
        filter.setDescription("PNG files");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(cd);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
          file = chooser.getSelectedFile();
        } else
          return;
        /* render layout to file */
        VisualGraph vg = getVisualGraph();
        Dimension dim = vg.getMaxSize();
        BufferedImage im = new BufferedImage(dim.width, dim.height,
            BufferedImage.TYPE_INT_RGB);
        Graphics2D g = im.createGraphics();
        g.setBackground(Color.WHITE);
        g.clearRect(0, 0, dim.width, dim.height);
        vg.paint(g);
        try {
          ImageIO.write(im, "png", file);
        } catch (IOException e1) {
          e1.printStackTrace();
        }
      }
    });

    menu.add(item);
    item = new JMenuItem("Quit");
    item.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
    menu.add(item);
    menu = new JMenu("Edit");
    item = new JMenu("Filter links");
    menu.add(item);
    JMenuItem subitem = new JCheckBoxMenuItem("Inheritance", inheritance);
    subitem.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          inheritance = true;
          break;
        case ItemEvent.DESELECTED:
          inheritance = false;
          break;
        }
        updateGraph();
      }
    });
    item.add(subitem);
    subitem = new JCheckBoxMenuItem("Dependance", dependance);
    subitem.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          dependance = true;
          break;
        case ItemEvent.DESELECTED:
          dependance = false;
          break;
        }
        updateGraph();
      }
    });
    item.add(subitem);
    subitem = new JCheckBoxMenuItem("Implements", dependance);
    subitem.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          implementation = true;
          break;
        case ItemEvent.DESELECTED:
          implementation = false;
          break;
        }
        updateGraph();
      }
    });
    item.add(subitem);
    subitem = new JCheckBoxMenuItem("References", references);
    subitem.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          references = true;
          break;
        case ItemEvent.DESELECTED:
          references = false;
          break;
        }
        updateGraph();
      }
    });
    item.add(subitem);
    item = new JCheckBoxMenuItem("Package", packages);
    item.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          packages = true;
          /* apply morphism */
          break;
        case ItemEvent.DESELECTED:
          packages = false;
          break;
        }
        updateGraph();
      }
    });
    menu.add(item);
    item = new JCheckBoxMenuItem("Collapsed", collapsed);
    item.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        switch (e.getStateChange()) {
        case ItemEvent.SELECTED:
          collapsed = true;
          try {
            foldGraph();
          } catch (Exception e1) {
            JOptionPane
                .showMessageDialog(cd, "Cannot compute SCC graph :" + e1);
          }
          break;
        case ItemEvent.DESELECTED:
          collapsed = false;
          unfoldGraph();
          break;
        }

      }
    });
    menu.add(item);
    item = new JMenu("Zoom");
    JMenuItem item2 = new JMenuItem("in");
    item2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        zoomIn();
      }
    });
    item.add(item2);
    item2 = new JMenuItem("out");
    item2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        zoomOut();
      }
    });
    item.add(item2);
    menu.add(item);
    menubar.add(menu);

    return menubar;
  }

  /**
   * 
   */
  protected void updateGraph() {
    try {
      if (this.packages)
        this.current = GraphOps.morph(this.graph, packageMorphism);
      else
        this.current = graph;
      /* apply required filters */
      GraphFilter flt = null;
      if (!dependance)
        flt = depFilter;
      if (!inheritance)
        if (flt != null)
          flt = new AndGraphFilter(flt, inhFilter);
        else
          flt = inhFilter;
      if (!implementation)
        if (flt != null)
          flt = new AndGraphFilter(flt, impFilter);
        else
          flt = impFilter;
      if (!references)
        if (flt != null)
          flt = new AndGraphFilter(flt, refFilter);
        else
          flt = refFilter;
      if (flt != null)
        this.current = GraphOps.filter(this.current, flt);
    } catch (Exception e) {
      e.printStackTrace();
      JOptionPane.showMessageDialog(this, "Unable to udpate graph view :"
          + e.getMessage());
      return;
    }
    setGraph(this.current);
    doGraphLayout();
  }

  /**
   * 
   */
  protected void unfoldGraph() {
    setGraph(this.graph);
    doGraphLayout();

  }

  /**
   * 
   */
  protected void foldGraph() throws Exception {
    if (this.colGraph == null) {
      TarjanSCC scc = new TarjanSCC(graph);
      this.colGraph = scc.makeCollapsedSCC();
    }
    setGraph(this.colGraph);
    doGraphLayout();
  }

  /**
   * @param dir
   */
  private static List listFiles(File dir) {
    List ret = new ArrayList();
    File[] files = dir.listFiles(new FileFilter() {

      public boolean accept(File pathname) {
        if (pathname.canRead() && pathname.getName().endsWith(".class"))
          return true;
        if (pathname.isDirectory())
          return true;
        return false;
      }

    });
    for (int i = 0; i < files.length; i++)
      if (!files[i].isDirectory())
        ret.add(files[i]);
      else
        ret.addAll(listFiles(files[i]));
    return ret;
  }

  /**
   * Add a new ClassFile to this graph. The ClassFile object is scanned for
   * ClassData constants which are added to the graph. A map from strings to
   * vertices is maintained.
   * 
   * @param cf
   */
  private void add(ClassFile cf) throws Exception {
    String clname = cf.getClassFileInfo().getName();
    String supname = cf.getClassFileInfo().getParentName();
    Set ifaces = cf.getClassFileInfo().getInterfacesNames();
    /* adds the class to analyzed set */
    analyzed.add(clname);
    /* create vertex if it does not exists */
    Object v = (Object) vertexMap.get(clname);
    if (v == null) {
      v = clname;
      graph.add(v);
      vertexMap.put(clname, v);
    }
    /* increase link count */
    VertexStat vs = (VertexStat) statMap.get(v);
    if (vs == null) {
      vs = new VertexStat(v);
      statMap.put(v, vs);
    }
    /* enumerate class data constants */
    Iterator it = cf.getConstantPool().getAllClassData().iterator();
    while (it.hasNext()) {
      String ocn = (String) it.next();
      /* filter out system classes : java.*, com.sun.*, javax.* */
      if (!filter(ocn)) {
        System.err.println("filtering out " + ocn);
        continue;
      }
      if (ocn.equals(clname))
        continue;

      String type = "<<uses>>";
      /* check kind of link */
      if (ocn.equals(supname))
        type = "<<inherits>>";
      else if (ifaces.contains(ocn))
        type = "<<implements>>";

      /* find vertex */
      Object ov = vertexMap.get(ocn);
      if (ov == null) {
        ov = ocn;
        vertexMap.put(ocn, ov);
      }
      /* increase link count */
      VertexStat ovs = (VertexStat) statMap.get(ov);
      if (ovs == null) {
        ovs = new VertexStat(ov);
        statMap.put(ov, ovs);
      }
      if (ovs.linkTo++ > curmaxlinks)
        rootv = ov;
      vs.linkFrom++;
      /* create edge */
      graph.add(ov);
      // System.err.println("Linking " + v + " to " + ov);
      if (graph.getEdge(v, ov) == null)
        graph.addEdge(new DirectedEdgeImpl(v, ov, type));
    }
  }

  /**
   * @param ocn
   * @return
   */
  private boolean filter(String ocn) {
    if (ocn.startsWith("java/") || ocn.startsWith("javax/")
        || ocn.startsWith("com/sun") || ocn.startsWith("sun/")
        || ocn.startsWith("sunw/") || ocn.startsWith("["))
      return false;
    /* apply local filter */
    Iterator it = filtered.iterator();
    while (it.hasNext()) {
      String pat = (String) it.next();
      if (ocn.startsWith(pat))
        return false;
    }
    return true;

  }

  private void zoomIn() {
    if (zoomFactor < maxZoom) {
      zoomFactor = zoomFactor * 2;
      gpanel.setZoomFactor(((double) zoomFactor) / (double) 1024);
    }
  }

  private void zoomOut() {
    if (zoomFactor > minZoom) {
      zoomFactor = zoomFactor / 2;
      gpanel.setZoomFactor(((double) zoomFactor) / (double) 1024);
    }
  }
}