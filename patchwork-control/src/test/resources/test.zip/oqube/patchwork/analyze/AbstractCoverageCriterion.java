/*______________________________________________________________________________
 * 
 * Copyright 2005 Arnaud Bailly - NORSYS/LIFL
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * (1) Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * (2) Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * (3) The name of the author may not be used to endorse or promote
 *     products derived from this software without specific prior
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Created on 21 avr. 2005
 *
 */
package oqube.patchwork.analyze;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import oqube.patchwork.graph.BasicBlock;

import salvo.jesus.graph.DirectedEdge;

/**
 * @author nono
 * @version $Id: AbstractCoverageCriterion.java 1322 2006-09-28 16:32:02Z /CN=nono $
 */
public abstract class AbstractCoverageCriterion implements CoverageCriterion {

    /**
     * Transform a list of directed edges between nodes 
     * containing basic blocks into a list of Integer 
     * objects whose numbers are the blocks' id.
     * 
     * @param l a List of of List of DirectedEdge ojects
     * @return a List of List of Integer 
     * 
     */
    protected List makeBlockList(List l) {
        List ret;
        ret = new ArrayList();
        for(Iterator i = l.iterator();i.hasNext();) {
            List ts = (List)i.next();
            if(ts.isEmpty())
                continue;
            List rs = new ArrayList();
            DirectedEdge de = null;
            for(Iterator i2 = ts.iterator();i2.hasNext();) {
                de = (DirectedEdge)i2.next();
                rs.add(Integer.toString(((BasicBlock)de.getSource()).getNumBlock()));
            }
            rs.add (Integer.toString(((BasicBlock)de.getSink()).getNumBlock()));
            ret.add(rs);
        }
        return ret;
    }

    protected final Comparator edgecomp = new Comparator() {
            public boolean equals(Object obj) {
                return false;
            }
    
            public int compare(Object o1, Object o2) {
                DirectedEdge de1 = (DirectedEdge) o1;
                DirectedEdge de2 = (DirectedEdge) o2;
                boolean d1d2 = de1.getSink().equals(de2.getSource());
                boolean d2d1 = de1.getSource().equals(de2.getSink());
                if (d1d2 && !d2d1)
                    return -1;
                if (!d1d2 && d2d1)
                    return 1;
                return 0;
            }
        };
    
    

}
