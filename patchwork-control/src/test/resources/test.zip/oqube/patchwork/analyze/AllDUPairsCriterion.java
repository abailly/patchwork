/*______________________________________________________________________________
 * 
 * Copyright 2005 Arnaud Bailly - NORSYS/LIFL
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * (1) Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * (2) Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * (3) The name of the author may not be used to endorse or promote
 *     products derived from this software without specific prior
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Created on Dec 28, 2005
 *
 */
package oqube.patchwork.analyze;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import oqube.patchwork.graph.ControlGraph;
import oqube.patchwork.graph.DataFlowGraph;
import oqube.patchwork.graph.DataFlowGraph.CUseNode;
import oqube.patchwork.graph.DataFlowGraph.DefNode;
import oqube.patchwork.graph.DataFlowGraph.UseNode;

import salvo.jesus.graph.DirectedEdge;
import salvo.jesus.graph.DirectedGraph;
import salvo.jesus.graph.Visitor;
import salvo.jesus.graph.algorithm.DFDirectedGraphEdgeTraversal;

/**
 * Compute list of blocks for testing du-pairs criteria.
 * <p>
 * This criterion implements the <em>all def-use pairs</em> criterion
 * from classical data-flow based structural coverage. It does so by
 * first constructing the data-flow graph then identifying paths from each 
 * definition of a variable to each use of <strong>this</strong> definition.
 * </p> 
 * <p>
 * Constructed sequences are completed with prologue from start node.
 * </p>
 * 
 * @author nono
 * @version $Id: AllDUPairsCriterion.java 1322 2006-09-28 16:32:02Z /CN=nono $
 */
public class AllDUPairsCriterion extends AbstractCoverageCriterion {

    /* (non-Javadoc)
     * @see fr.norsys.klass.graph.CoverageCriterion#suite(fr.norsys.klass.graph.ControlGraph)
     */
    public List suite(ControlGraph cg) {
        List ret = new ArrayList();
        /* compute data-flow graph */
        DataFlowGraph dfg;
        try {
            dfg = new DataFlowGraph(cg,256);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList();
        }
        /* 
         * construct suite
         * we traverse the graph from each definition node to each use node
         * and register the pair iff there is no other definition for 
         * this variable 
         */
        /* first identify all defs */
        List defs = new ArrayList();
        for(Iterator i = dfg.getGraph().getAllVertices().iterator();i.hasNext();) {
            Object v = i.next();
            if(v instanceof DataFlowGraph.DefNode) {
                defs.add(v);
            }
        }
        /* then do traversal from each def */
        for(Iterator i = defs.iterator();i.hasNext();) {
            Object v = i.next();
            List l = makeDUPairs((DefNode)v,dfg.getGraph());
            ret.addAll(l);
        }        
        /* transform list of edges to list of blocks */
        return ret;
    }
    

    /**
     * Construct DU pairs for given definition node.
     * This method traverse all edges of the underlying graph starting from
     * given node registering def-clear paths to equivalent use nodes.
     * 
     * @param def
     * @return
     */
    private List makeDUPairs(DefNode def,DirectedGraph dgraph) {
        /* contains list of paths of definition clear du pairs */
        List /* < List > */ ret = new ArrayList();
        DirectedEdge next;
        Object adjacent;
        DirectedEdge edge;
        Stack stack = new Stack();
        Set visited = new HashSet();
        
        // Push the starting vertex onto the stack
        for (Iterator it = dgraph.getOutgoingEdges(def).iterator(); it
                .hasNext();) {
            stack.push(it.next());
        }

        do {
            /* get next edge and mark it */
            next = (DirectedEdge) stack.pop();
            if(visited.contains(next))
                continue;
            else
                visited.add(next);
            
            // Gadjacent vertice, respecting the edge direction,
            if (next.getDirection() == DirectedEdge.DIRECTION_A_TO_B)
                adjacent = next.getVertexB();
            else
                adjacent = next.getVertexA();

            /* check this is a def clear path - if not, continue */
            if(adjacent instanceof DefNode) {
                if(((DefNode)adjacent).getIndex() == def.getIndex()) 
                    continue;
            }
            /* is this a matching use node ? */
            if(adjacent instanceof UseNode) {
                if(((UseNode)adjacent).getIndex() == def.getIndex()) {
                    List l = new ArrayList(stack);
                    l.add(next);
                    /* we found a du pair, store it */
                    ret.add(l);
                }
            }
            /* continue traversal */
            stack.push(next);
            for (Iterator it = dgraph.getOutgoingEdges(adjacent)
                    .iterator(); it.hasNext();) {
                edge = (DirectedEdge) it.next();
                if (!visited.contains(edge) && !stack.contains(edge)) {
                    stack.push(edge);
                }
            }

        } while (!stack.isEmpty());
        return ret;        
    }
    
    public String toString() {
        return "All DU pairs";
    }
}
