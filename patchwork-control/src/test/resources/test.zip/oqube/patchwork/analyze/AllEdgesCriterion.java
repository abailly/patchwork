/*______________________________________________________________________________
 * 
 * Copyright 2005 Arnaud Bailly - NORSYS/LIFL
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * (1) Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * (2) Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * (3) The name of the author may not be used to endorse or promote
 *     products derived from this software without specific prior
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Created on 3 avr. 2005
 *
 */
package oqube.patchwork.analyze;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oqube.patchwork.graph.BasicBlock;
import oqube.patchwork.graph.ControlGraph;

import salvo.jesus.graph.DirectedEdge;
import salvo.jesus.graph.DirectedGraph;
import salvo.jesus.graph.algorithm.CycleBase;
import salvo.jesus.graph.algorithm.DFDirectedGraphEdgeTraversal;

/**
 * This class constructs a test suite that meet all-edges criterion.
 * <p>
 * The test sequences are constructed using depth first traversal of 
 * control flow graph.
 * 
 * @author nono
 * @version $Id: AllEdgesCriterion.java 1322 2006-09-28 16:32:02Z /CN=nono $
 */
public class AllEdgesCriterion extends AbstractCoverageCriterion {


    /* (non-Javadoc)
     * @see fr.norsys.klass.	graph.CoverageCriterion#suite(fr.norsys.klass.graph.ControlGraph)
     */
    public List suite(ControlGraph cg) {
        DirectedGraph bg  = cg.getGraph();
        DFDirectedGraphEdgeTraversal trv = new DFDirectedGraphEdgeTraversal(bg);
        BasicBlock start = new BasicBlock.StartBlock();
        List l = trv.traverse(bg.findVertex(start));
        List ret = new ArrayList();
        /* store map from vertices to shortest list of edges traversing this vertex */
        Map /* < Vertex , List < Edges > > */ suff = new HashMap();
        /* construct list of test suites */
        List cur = new ArrayList();
        Object v = null;
        for(Iterator i = l.iterator();i.hasNext();) {
            DirectedEdge de = (DirectedEdge)i.next();
            Object from  = de.getSource();
            if (v != from) {
                cur = new ArrayList();
                ret.add(cur);
            }
            cur.add(de);
            v = from = de.getSink();
            /* update suff */
            List sl = (List)suff.get(from);
            if(sl == null || sl.size() > cur.size()) 
                suff.put(from,new ArrayList(cur));
        }
        /* link suites */
        l = new ArrayList();
        for(Iterator i = ret.iterator();i.hasNext();) {
            List ts = (List)i.next();
            if(ts.isEmpty())
                continue;
            DirectedEdge de = (DirectedEdge)ts.get(0);
            while(!start.equals(de.getSource())) {
                /* extract sublist */
                List li = (List)suff.get(de.getSource());
                ts.addAll(0,li);
                de = (DirectedEdge)ts.get(0);
            }
            l.add(ts);
        }
        /* return list of covered blocks */
        ret = makeBlockList(l);
        return ret;
    }

    public String toString() {
        return "All Edges";
    }

    /* (non-Javadoc)
     * @see fr.norsys.klass.graph.CoverageCriterion#suite(fr.norsys.klass.graph.ControlGraph)
     */
    public List suite2(ControlGraph cg) {
        DirectedGraph dg =  cg.getGraph();
        CycleBase base = new CycleBase(dg);
        Set /* < DirectedGraph > */ bases = base.base();
        /* construct a map from start vertex of each directed graph */
        Map /* < Vertex , List < Edge > > */ stmap = new HashMap();
        for(Iterator i = bases.iterator();i.hasNext();) {
            DirectedGraph path = (DirectedGraph)i.next();
            List edges = path.getAllEdges();
            Collections.sort(edges,edgecomp);
            DirectedEdge de = (DirectedEdge)edges.get(0);
            stmap.put(de.getSource(),edges);
        }
        /* construct paths from start block to end block */
        
        return null;
    }
}
