/**
 * 
 */
package oqube.patchwork.graph;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import oqube.bytes.ClassFile;
import oqube.bytes.attributes.CodeAttribute;
import oqube.bytes.struct.MethodFileInfo;

/**
 * A caching control graph builder. This builder caches the control graphs it
 * creates and may extract its data from an encapsulated class loader.
 * 
 * @author nono
 */
public class CachedControlGraphBuilder implements ControlGraphBuilder {

  /*
   * the class loader to use
   */
  private ClassLoader loader = getClass().getClassLoader();

  /*
   * the cached control graphs.
   */
  private Map<String, ControlGraph> cache = new HashMap<String, ControlGraph>();

  public Map<String, ControlGraph> createAllGraphs(InputStream is)
      throws IOException {
    ClassFile cf = new ClassFile();
    try {
      cf.read(new DataInputStream(is));
    } catch (FileNotFoundException e) {
      throw e;
    } catch (IOException e) {
      throw e;
    }
    // class name
    String cln = cf.getClassFileInfo().getName();
    Map<String, ControlGraph> map = new HashMap<String, ControlGraph>();
    Iterator it = cf.getAllMethods().iterator();
    while (it.hasNext()) {
      MethodFileInfo mfi = (MethodFileInfo) it.next();
      String mname = mfi.getName() + mfi.getSignature();
      String fulln = cln + "." + mname;
      ControlGraph cgraph = cache.get(fulln);
      if (cgraph == null) {
        CodeAttribute code = mfi.getCodeAttribute();
        if (code == null) // abstract method
          continue;
        try {
          cgraph = new ControlGraph(mfi);
          cache.put(fulln, cgraph);
        } catch (Exception e1) {
          throw new IOException("I/O error while reading method "
              + cf.getClassFileInfo().getName() + "." + mname + " : "
              + e1.getMessage());
        }
      }
      assert cgraph != null;
      map.put(fulln, cgraph);
    }
    return map;
  }

  /**
   * Factory method for creating graph for a single method in a class. This
   * method loads the class from the loader this builder is attached to, locates
   * the requested method and returns the control flow graph constructed if it
   * exists.
   * 
   * @param cls
   *          class name
   * @param method
   *          a method name
   * @param signature
   *          signature of method
   * @return a control graph for given method or null.
   * @throws IOException
   *           if cannot find information. This may comes from a problem in
   *           classpath or in names.
   */
  public ControlGraph createGraphForMethod(String cls, String method,
      String signature) throws IOException {
    // lookup in cache
    String fulln = cls.replace('.', '/') + "." + method + signature;
    ControlGraph cg;
    if ((cg = cache.get(fulln)) != null)
      return cg;
    // create all graph for this class
    cg = createGraphsForClass(cls).get(fulln);
    if (cg == null)
      throw new IOException("Unable to create control graph for " + method);
    else
      return cg;
  }

  /**
   * Factory method for creating all control flow graphs of a given class. This
   * method extracts a stream from the current classpath and then calls
   * {@link #createAllGraphs(InputStream)}.
   * 
   * @param cls
   *          name of the class to get graphs for.
   * @return a Map<String,ControlGraph> from method names (with signatures) to
   *         their control flow graph.
   * @throws IOException
   */
  public Map<String, ControlGraph> createGraphsForClass(String cls)
      throws IOException {
    // get stream
    InputStream is = loader.getResourceAsStream(cls.replace('.', '/')
        + ".class");
    if (is == null)
      throw new IOException("Cannot load code for class " + cls);
    return createAllGraphs(is);
  }

  /**
   * @return the loader
   */
  public ClassLoader getLoader() {
    return loader;
  }

  /**
   * @param loader
   *          the loader to set
   */
  public void setLoader(ClassLoader loader) {
    this.loader = loader;
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.graph.ControlGraphBuilder#createGraphForMethod(java.lang.String)
   */
  public ControlGraph createGraphForMethod(String method) throws IOException {
    ControlGraph cg;
    if ((cg = cache.get(method)) != null)
      return cg;
    int dot = method.lastIndexOf('.');
    int paren = method.lastIndexOf('(');
    String cln = method.substring(0, dot);
    String mn = method.substring(dot + 1, paren);
    String signature = method.substring(paren);
    return createGraphForMethod(cln, mn, signature);
  }

}
