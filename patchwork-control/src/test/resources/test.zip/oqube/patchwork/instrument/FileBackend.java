/*______________________________________________________________________________
 * 
 * Copyright 2006 Arnaud Bailly - NORSYS/LIFL
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * (1) Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * (2) Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * (3) The name of the author may not be used to endorse or promote
 *     products derived from this software without specific prior
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Created on Jan 3, 2006
 *
 */
package oqube.patchwork.instrument;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import oqube.patchwork.report.coverage.CoverageObjective;
import oqube.patchwork.report.coverage.ObjectiveBuilder;
import oqube.patchwork.report.coverage.PackageTreeCoverageBuilder;
import oqube.patchwork.report.coverage.SimpleTextOutput;

/**
 * A base class for storing the content of a coverage report into a file.
 * <p>
 * This class stores a coverage report information into a file.
 * 
 * @author nono
 * @version $Id: FileBackend.java 1348 2007-01-23 12:27:06Z /CN=nono $
 */
public class FileBackend implements CoverageBackend {

  /*
   * the file where coverage data is stored.
   */
  private File file;

  private FileOutputStream stream;

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.CoverageReporter#getCoverageStream()
   */
  public OutputStream getCoverageStream() {
    long timestamp = new Date().getTime();
    this.file = new File("patchwork" + timestamp);
    try {
      return stream = new FileOutputStream(file);
    } catch (FileNotFoundException e) {
      throw new Error("Cannot open output file");
    }
  }

  public void start() {
  }

  public void done() {
    try {
      if (stream != null) {
        stream.flush();
        stream.close();
      }
    } catch (IOException e) {
      // IGNORED ?
    }
  }

}
