/**
 * 
 */
package oqube.patchwork.report;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;

import fr.lifl.utils.Pipe;

import oqube.patchwork.instrument.CoverageBackend;
import oqube.patchwork.report.OnlineBackendTest.StubReporter;

/**
 * An coverage backend that consumes report events immediately and dispatches
 * them to a reporter. This online backend is effectively a simple pipe that
 * transmits data from {@link Coverage} class to a {@link Reporter} instance.
 * 
 * @author nono
 * 
 */
public class OnlineBackend implements CoverageBackend {

  /*
   * the reporter where data is sent to.
   */
  private Reporter reporter;

  private PipedInputStream reporterStream;

  private PipedOutputStream coverageStream;

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.instrument.CoverageBackend#done()
   */
  public void done() {
    try {
      int i = 0;
      coverageStream.flush();
      System.err.println("flushed coverage output stream");
      // wait for reporter thread
      while ((i = reporterStream.available()) > 0) {
        System.err.println("Still " + i + " bytes to be read, yielding");
        Thread.yield();
      }
      coverageStream.close();
      reporterStream.close();
    } catch (IOException e) {
      // ???
      e.printStackTrace();
    }
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.instrument.CoverageBackend#getCoverageStream()
   */
  public OutputStream getCoverageStream() {
    return coverageStream;
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.instrument.CoverageBackend#start()
   */
  public void start() {
    // setup streams
    reporterStream = new PipedInputStream();
    coverageStream = new PipedOutputStream();
    try {
      reporterStream.connect(coverageStream);
    } catch (IOException e1) {
      // dont know what to do
      e1.printStackTrace();
    }
    // calls asynchronously reporter to analyse stream
    new Thread() {
      public void run() {
        try {
          reporter.analyze(reporterStream);
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }.start();
  }

  public void setReporter(Reporter rep) {
    this.reporter = rep;
  }

}
