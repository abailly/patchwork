/**
 *  Copyright (C) 2006 - OQube / Arnaud Bailly
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

 Created 11 sept. 2006
 */
package oqube.patchwork.report;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.logging.Logger;

import oqube.patchwork.graph.ControlGraphBuilder;
import oqube.patchwork.report.coverage.AllEdgesObjective;
import oqube.patchwork.report.coverage.CoverageObjective;
import oqube.patchwork.report.coverage.OutputFormatter;
import oqube.patchwork.report.coverage.PackageTreeCoverageBuilder;
import oqube.patchwork.report.coverage.SimpleTextOutput;
import oqube.patchwork.report.coverage.SourceMapper;
import oqube.patchwork.report.coverage.XHTMLFormatter;
import fr.lifl.utils.CommandLine;

/**
 * This reporter reads data from a coverage stream and produces nodes and edges
 * coverage information
 * 
 * @author nono
 * 
 */
public class SimpleReporter implements Reporter {

  private CoverageObjective objective;

  private OutputFormatter output = new SimpleTextOutput();

  private static final Logger log = Logger.getLogger(SimpleReporter.class
      .getName());

  private SourceMapper sourceMapper;

  /*
   * class loader for loading binary data from
   */
  private ClassLoader loader = getClass().getClassLoader();

  private ControlGraphBuilder graphBuilder;

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.Reporter#analyze(java.io.InputStream)
   */
  public void analyze(InputStream is) throws IOException {
    log.info("Start analyzing coverage stream");
    long ts = System.nanoTime();
    String[][] names = readClassesAndMethods(is);
    // extract class names
    Set cls = new HashSet();
    for (int i = 0; i < names.length; i++)
      cls.add(names[i][0]);
    if (objective == null) {
      PackageTreeCoverageBuilder builder = new PackageTreeCoverageBuilder();
      builder.setLog(log);
      builder.setGraphBuilder(graphBuilder);
      builder.setObjectiveClass(AllEdgesObjective.class);
      objective = builder.build(cls);
    }
    if (sourceMapper != null) {
      sourceMapper.setLog(log);
      sourceMapper.setGraphBuilder(graphBuilder);
    }
    updateCoverageFromStream(names, is);
    log.info("done analyzing coverage stream in " + (System.nanoTime() - ts)
        / 1000000 + " ms");
  }

  private void updateCoverageFromStream(String[][] names, InputStream is) {
    BufferedInputStream bis = new BufferedInputStream(is,Coverage.bufferSize);
    DataInputStream dis = new DataInputStream(bis);
    long val = 0;
    int ln = 0;
    try {
       while(true){
         val =dis.readLong();
          if (val == -1) {
            // mark - should do something, but what ?
          } else {
            // extract info from val
            short tid = (short) ((val >> 48) & 0xffff);
            short cid = (short) ((val >> 32) & 0xffff);
            assert cid < names.length;
            short mid = (short) ((val >> 16) & 0xffff);
            assert mid < names[cid].length;
            short bid = (short) (val & 0xffff);
            String mname = names[cid][mid + 1];
            objective.update(tid, mname, bid);
            if (sourceMapper != null)
              sourceMapper.update(tid, mname, bid);
          }
        }
    } catch (EOFException e) {
      // NOP
    } catch (IOException e) {
      log.severe("IO Error while reading coverage information");
      e.printStackTrace();
    }
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.Reporter#report(java.io.OutputStream)
   */
  public void report(OutputStream os) {
    output.setOut(new PrintWriter(os));
    output.setSourceMap(sourceMapper);
    output.start();
    // report simple
    objective.visit(output);
    output.done();
  }

  /**
   * This method is used to read the informations in a coverage file. It reads
   * data from an input stream, wraps it in a data stream and returns a two
   * dimensional array of strings where the first string in a line is the class
   * name followed by its method names. Note that it does not modifies the
   * stream in any way other than reading it, which means that the position of
   * the stream when this method returns is the start of block execution
   * recording.
   *  
   * @param stream
   *          data stream
   * @return a String[][] array with names.
   * @throws IOException
   *           If error in reading stream.
   */
  String[][] readClassesAndMethods(InputStream is) throws IOException {
    DataInputStream dis = new DataInputStream(is);
    int sz = dis.readInt();
    String[][] ret = new String[sz][];
    for (int i = 0; i < sz; i++) {
      String cln = dis.readUTF();
      int nm = dis.readInt();
      ret[i] = new String[nm + 1];
      ret[i][0] = cln;
      for (int j = 0; j < nm; j++) {
        ret[i][j + 1] = cln + '.' + dis.readUTF();
      }
    }
    return ret;
  }

  /**
   * @return Returns the sourceMapper.
   */
  public SourceMapper getSourceMapper() {
    return sourceMapper;
  }

  /**
   * @param sourceMapper
   *          The sourceMapper to set.
   */
  public void setSourceMapper(SourceMapper sourceMapper) {
    this.sourceMapper = sourceMapper;
    sourceMapper.setLoader(loader);
  }

  /**
   * @return the loader
   */
  public ClassLoader getLoader() {
    return loader;
  }

  /**
   * @param loader
   *          the loader to set
   */
  public void setLoader(ClassLoader loader) {
    this.loader = loader;
    if (sourceMapper != null)
      sourceMapper.setLoader(loader);
  }

  /**
   * @return Returns the output.
   */
  public OutputFormatter getOutput() {
    return output;
  }

  /**
   * @param output
   *          The output to set.
   */
  public void setOutput(OutputFormatter output) {
    this.output = output;
  }

  /**
   * @return Returns the objective.
   */
  public CoverageObjective getObjective() {
    return objective;
  }

  /**
   * @param objective
   *          The objective to set.
   */
  public void setObjective(CoverageObjective objective) {
    this.objective = objective;
  }

  /**
   * @return the graphBuilder
   */
  public ControlGraphBuilder getGraphBuilder() {
    return graphBuilder;
  }

  /**
   * @param graphBuilder the graphBuilder to set
   */
  public void setGraphBuilder(ControlGraphBuilder graphBuilder) {
    this.graphBuilder = graphBuilder;
  }

}
