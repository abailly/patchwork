/**
 *  Copyright (C) 2006 - OQube / Arnaud Bailly
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

 Created 12 sept. 2006
 */
package oqube.patchwork.report.coverage;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import com.thoughtworks.qdox.JavaDocBuilder;
import com.thoughtworks.qdox.model.JavaClass;
import com.thoughtworks.qdox.model.JavaSource;
import com.uwyn.jhighlight.renderer.JavaXhtmlRenderer;

import oqube.patchwork.graph.BasicBlock;
import oqube.patchwork.graph.ControlGraph;
import oqube.patchwork.graph.ControlGraphBuilder;
import oqube.patchwork.report.CoverageListener;

/**
 * A utility class that constructs a map from class names to source URLs using a
 * sourcepath list and that can highlight source code for executed blocks. This
 * class can be used if source code rendering is needed.
 * 
 * @author nono
 * 
 */
public class SourceMapper implements CoverageListener {

  private Logger log;

  /*
   * map from class names to source files
   */
  private Map<String, URL> sourceMap = new HashMap<String, URL>();

  private JavaDocBuilder builder = new JavaDocBuilder();

  /*
   * loader for binary data on classes.
   */
  private ClassLoader loader = getClass().getClassLoader();

  /*
   * renderer for outputting highlighted source code
   */
  private JavaXhtmlRenderer renderer = new JavaXhtmlRenderer();

  /* base directory for storing generated files */
  private File basedir = new File(".");

  private ControlGraphBuilder graphBuilder;

  /*
   * list of sourcepath entries (dirs, jars or zips)
   */
  private List<File> sourcePath = new ArrayList<File>();

  /*
   * prefix added to urls for highlighted files
   */
  private String urlPrefix = "";

  /*
   * a map from class names to list of source code segments covered.
   */
  private Map /* < String, BitSet> */hltLines = new HashMap();

  /**
   * Return a readable URL for given source file.
   * 
   * @param name
   *          a source file name relative to some path
   * @return a URL from where content of the file can be read or null.
   */
  public URL getURL(String name) {
    /* collect class files */
    for (File path : sourcePath) {
      if (path.isDirectory()) {
        File sf = new File(path, name);
        if (sf.exists())
          try {
            return sf.toURL();
          } catch (MalformedURLException e) {
            e.printStackTrace();
          }
        else
          return null;
      } else if (path.getName().endsWith(".jar")) {
        URL url;
        try {
          url = new URL("jar:" + path.toURL() + "/ " + name);
          InputStream sfis = url.openStream();
          // source file exists in this jar
          return url;
        } catch (MalformedURLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      } else if (path.getName().endsWith(".zip")) {
        try {
          URL url = new URL("zip:" + path.toURL() + "/ " + name);
          InputStream sfis = url.openStream();
          // source file exists in this jar
          return url;
        } catch (MalformedURLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      } else {
        return null;
      }
    }
    return null;
  }

  /**
   * Produce xhtml file for given name. Assume name is a dot or slash separated
   * list of components tha are transformed into directories.
   * 
   * @param name
   * @param url
   * @return
   */
  public String highlight(String name) {
    try {
      URL url = getURL(name);
      if (url == null)
        return null;
      InputStream is = url.openStream();
      /* create output file */
      String fname = basedir.getPath() + "/" + name + ".html";
      File dir = new File(fname.substring(0, fname.lastIndexOf('/')));
      if (!dir.exists())
        dir.mkdirs();
      // format source
      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      renderer.highlight(name, is, bos, "UTF-8", false);
      // add line coverage info
      // create bitset for covered lines
      BitSet cb = (BitSet) hltLines.get(name);
      if (cb != null && cb.cardinality() != 0)
        addCoveredLinesFormat(fname, bos.toByteArray(), cb);
      return urlPrefix + name + ".html";
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }

  /*
   * add span class around each covered line in source format.
   */
  private void addCoveredLinesFormat(String fname, byte[] bs, BitSet cb)
      throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(
        new ByteArrayInputStream(bs)));
    PrintStream pos = new PrintStream(new FileOutputStream(fname));
    String line;
    int ln = 0;
    Pattern pat = Pattern.compile("^<span class=\"java_.*");
    // match
    while ((line = br.readLine()) != null) {
      if (pat.matcher(line).matches()) {
        ln++;
        if (cb.get(ln))
          pos.append("<span style=\"background-color: lightgreen;\">").append(
              line).append("</span>");
        else
          pos.append(line);
      } else
        pos.append(line);
    }
    pos.flush();
    pos.close();
  }

  /**
   * @return Returns the log.
   */
  public Logger getLog() {
    return log;
  }

  /**
   * @param log
   *          The log to set.
   */
  public void setLog(Logger log) {
    this.log = log;
  }

  /**
   * @return Returns the sourceMap.
   */
  public Map getSourceMap() {
    return sourceMap;
  }

  /**
   * @param sourceMap
   *          The sourceMap to set.
   */
  public void setSourceMap(Map sourceMap) {
    this.sourceMap = sourceMap;
  }

  /**
   * Update coverage information for this source mapper. The given path lists is
   * used to highlight source code by translating executed blocks to their line
   * equivalent.
   * 
   * @param cp
   *          a Map<String, List<int[]>> instance from full method names to
   *          list of blocks.
   */
  public void update(Map cp) {
    for (Iterator i = cp.entrySet().iterator(); i.hasNext();) {
      Map.Entry me = (Map.Entry) i.next();
      String method = (String) me.getKey();
      List blocks = (List) me.getValue();
      if (blocks.isEmpty())
        continue;
      /* extract control flow graph */
      int dot = method.lastIndexOf('.');
      if (dot == -1)
        throw new IllegalArgumentException("Invalid method name " + method
            + ": Must be <class>.<method><signature>");
      int paren = method.lastIndexOf('(');
      if (paren == -1)
        throw new IllegalArgumentException("Invalid signature in " + method
            + ": Must be <class>.<method><signature>");
      String cln = method.substring(0, dot);
      String mn = method.substring(dot + 1, paren);
      String signature = method.substring(paren);
      try {
        ControlGraph cg = graphBuilder.createGraphForMethod(cln, mn, signature);
        // order cg blocks by source lines numbers
        Comparator comp = new Comparator() {
          public int compare(Object arg0, Object arg1) {
            BasicBlock bb1 = (BasicBlock) arg0;
            BasicBlock bb2 = (BasicBlock) arg1;
            int s1, s2, e1, e2;
            s1 = bb1.getStartLine();
            s2 = bb2.getStartLine();
            e1 = bb1.getEndLine();
            e2 = bb2.getEndLine();
            return s1 < s2 ? -1 : s1 > s2 ? 1 : (e1 < e2 ? -1 : (e1 > e2 ? 1
                : 0));
          }
        };
        List l = cg.getBlocks();
        if (l.isEmpty())
          continue;
        Collections.sort(l, comp);
        // laready covered lines
        BitSet cov = (BitSet) hltLines.get(cln);
        if (cov == null) {
          cov = new BitSet();
          hltLines.put(cln, cov);
        }
        // add all covered blocks to this class coverage info
        for (Iterator j = blocks.iterator(); j.hasNext();) {
          int[] path = (int[]) j.next();
          for (int k = 0; k < path.length; k++) {
            BasicBlock bb = (BasicBlock) l.get(path[k] - 1);
            for (int m = bb.getStartLine(); m <= bb.getEndLine(); m++)
              cov.set(m - 1);
          }
        }
      } catch (IOException e) {
        log.severe("Cannot construct graph for method " + method);
        e.printStackTrace();
      }
    }
  }

  /**
   * @return the loader
   */
  public ClassLoader getLoader() {
    return loader;
  }

  /**
   * @param loader
   *          the loader to set
   */
  public void setLoader(ClassLoader loader) {
    this.loader = loader;
  }

  /**
   * Online update of covered lines information. This method is inefficient and
   * need to be refactored.
   */
  public void update(int tid, String method, int block) {
    ControlGraph cg;
    try {
      cg = graphBuilder.createGraphForMethod(method);
    } catch (IOException e) {
      e.printStackTrace();
      return;
    }
    // order cg blocks by source lines numbers
    Comparator comp = new Comparator() {
      public int compare(Object arg0, Object arg1) {
        BasicBlock bb1 = (BasicBlock) arg0;
        BasicBlock bb2 = (BasicBlock) arg1;
        int s1, s2, e1, e2;
        s1 = bb1.getStartLine();
        s2 = bb2.getStartLine();
        e1 = bb1.getEndLine();
        e2 = bb2.getEndLine();
        return s1 < s2 ? -1 : s1 > s2 ? 1 : (e1 < e2 ? -1 : (e1 > e2 ? 1 : 0));
      }
    };
    List l = cg.getBlocks();
    // skip start and end block
    if (l.isEmpty() || block == 0 || block > l.size())
      return;
    Collections.sort(l, comp);
    // already covered lines
    String cln = cg.getSourceFile();
    if (cln != null) {
      BitSet cov = (BitSet) hltLines.get(cln);
      if (cov == null) {
        cov = new BitSet();
        hltLines.put(cln, cov);
      }
      // add
      BasicBlock bb = (BasicBlock) l.get(block - 1);
      for (int m = bb.getStartLine(); m <= bb.getEndLine(); m++)
        cov.set(m - 1);
    }
  }

  /**
   * @return the graphBuilder
   */
  public ControlGraphBuilder getGraphBuilder() {
    return graphBuilder;
  }

  /**
   * @param graphBuilder
   *          the graphBuilder to set
   */
  public void setGraphBuilder(ControlGraphBuilder graphBuilder) {
    this.graphBuilder = graphBuilder;
  }

  /**
   * @return Returns the sourcePath.
   */
  public List<File> getSourcePath() {
    return sourcePath;
  }

  /**
   * @param sourcePath
   *          The sourcePath to set.
   */
  public void setSourcePath(List<File> sourcePath) {
    this.sourcePath = sourcePath;
  }
}
