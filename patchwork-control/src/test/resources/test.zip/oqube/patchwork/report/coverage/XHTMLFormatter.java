/**
 *  Copyright (C) 2006 - OQube / Arnaud Bailly
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

 Created 12 sept. 2006
 */
package oqube.patchwork.report.coverage;

import java.awt.geom.Arc2D.Double;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.uwyn.jhighlight.renderer.JavaXhtmlRenderer;

/**
 * Generate an XHMTL format of coverage information. This formatter creates a
 * single XHTML file for outputting coverage information of a complete tree of
 * coverage objectives. Optionally, it generates links to decorated source
 * files.
 * 
 * 
 * @author nono
 * 
 */
public class XHTMLFormatter extends SimpleTextOutput {

  private NumberFormat nums = new DecimalFormat("0");

  private NumberFormat perc = new DecimalFormat("0.00 %");

  private SourceMapper sourceMap;

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.coverage.ObjectiveVisitor#visit(oqube.patchwork.report.coverage.AggregateObjective)
   */
  public void visit(AggregateObjective obj) {
    /* extract reference */
    String ref = null;
    if (sourceMap != null)
      ref = sourceMap.highlight(obj.getName());
    /* output header */
    out.append("<div id=\"").append(URLEncoder.encode(obj.getName())).append(
        "\" >").println();
    out.append("<h3>");
    if (ref != null)
      out.append("<a href=\"").append(ref).append("\" >");
    out.append(obj.getName());
    if (ref != null)
      out.append("</a>");
    out.append("</h3>");
    /* output body */
    for (Iterator i = obj.getObjectives().iterator(); i.hasNext();)
      ((CoverageObjective) i.next()).visit(this);
    out.append("</div>").println();
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.coverage.ObjectiveVisitor#visit(oqube.patchwork.report.coverage.AllNodesObjective)
   */
  public void visit(AllNodesObjective obj) {
    format("node-coverage", obj);
  }

  /**
   * @param obj
   */
  private void format(String cls, MethodObjective obj) {
    double percent = obj.coverage() / obj.high();
    if (obj.coverage() < obj.low())
      cls += "-low";
    else if (obj.coverage() < obj.high())
      cls += "-middle";
    else {
      assert obj.coverage() >= obj.high();
      cls += "-high";
    }
    out.append("<div class=\"").append(cls).append("\" id=\"").append(
        URLEncoder.encode(obj.getName())).append(
        "\"><span class=\"method-name\" >").append(obj.getMethodName()).append(
        "</span>");
    out.append("<span class=\"low\" >").append(nums.format(obj.low())).append(
        "</span>");
    out.append("<span class=\"high\" >").append(nums.format(obj.high()))
        .append("</span>");
    out.append("<span class=\"coverage\" >")
        .append(nums.format(obj.coverage())).append("</span>");
    out.append("<span class=\"percent\" >").append(perc.format(percent))
        .append("</span></div>");
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.coverage.ObjectiveVisitor#visit(oqube.patchwork.report.coverage.AllEdgesObjective)
   */
  public void visit(AllEdgesObjective obj) {
    format("edge-coverage", obj);
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.coverage.SimpleTextOutput#done()
   */
  public void done() {
    out.append("</body></html>");
    super.done();
  }

  /*
   * (non-Javadoc)
   * 
   * @see oqube.patchwork.report.coverage.SimpleTextOutput#start()
   */
  public void start() {
    super.start();
    out.append("<html><head><title>Coverage report</title>");
    // add css
    BufferedReader br = new BufferedReader(new InputStreamReader(getClass()
        .getResourceAsStream("/base.css")));
    out.append("<style type=\"text/css\">");
    String line;
    try {
      while ((line = br.readLine()) != null)
        out.append(line).println();
    } catch (IOException e) {
      // IGNORE ?
    }
    out.append("</style>");
    out.append("</head><body>");
  }

  /**
   * @return Returns the sourceMap.
   */
  public SourceMapper getSourceMap() {
    return sourceMap;
  }

  /**
   * @param sourceMap
   *          The sourceMap to set.
   */
  public void setSourceMap(SourceMapper sourceMap) {
    this.sourceMap = sourceMap;
  }
}
