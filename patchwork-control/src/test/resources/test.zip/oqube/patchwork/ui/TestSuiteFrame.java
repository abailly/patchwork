/*______________________________________________________________________________
 * 
 * Copyright 2005 Arnaud Bailly - NORSYS/LIFL
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * (1) Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * (2) Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * (3) The name of the author may not be used to endorse or promote
 *     products derived from this software without specific prior
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Created on 3 avr. 2005
 *
 */
package oqube.patchwork.ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import oqube.patchwork.analyze.AllCycleBasesCriterion;
import oqube.patchwork.analyze.AllDUPairsCriterion;
import oqube.patchwork.analyze.AllEdgesCriterion;
import oqube.patchwork.analyze.CoverageCriterion;
import oqube.patchwork.graph.ControlGraph;

/**
 * A frame that displays a list of sequences of blocks for various structural
 * testing criterions.
 * <p>
 * 
 * @author nono
 * @version $Id: TestSuiteFrame.java 1308 2006-09-12 20:16:45Z nono $
 */
public class TestSuiteFrame extends JFrame {

    private ControlGraph cg;

    private JList suites;

    class SimpleListModel extends AbstractListModel {

        private List l;

        SimpleListModel(List l) {
            this.l = l;
        }

        /*
         * (non-Javadoc)
         * 
         * @see javax.swing.ListModel#getSize()
         */
        public int getSize() {
            return l.size();
        }

        /*
         * (non-Javadoc)
         * 
         * @see javax.swing.ListModel#getElementAt(int)
         */
        public Object getElementAt(int index) {
            return l.get(index);
        }

    }

    /**
     * @throws java.awt.HeadlessException
     */
    public TestSuiteFrame() throws HeadlessException {
        super("Test Suite");
        initUI();
    }

    public void setControlGraph(ControlGraph cg) {
        this.cg = cg;
    }

    private void initUI() {
        Container cont = getContentPane();
        cont.setLayout(new BorderLayout());
        /* criterion selector */
        JComboBox box = new JComboBox(new CoverageCriterion[] {
                new CoverageCriterion() {
                    List empty = new ArrayList();

                    /*
                     * (non-Javadoc)
                     * 
                     * @see fr.norsys.klass.graph.CoverageCriterion#suite(fr.norsys.klass.graph.ControlGraph)
                     */
                    public List suite(ControlGraph cg) {
                        return empty;
                    }

                    public String toString() {
                        return "Choose a criterion";
                    }
                }, new AllEdgesCriterion(), new AllCycleBasesCriterion(),
                new AllDUPairsCriterion() });
        box.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    suites.setModel(new SimpleListModel(((CoverageCriterion) e
                            .getItem()).suite(cg)));
                }
            }
        });
        JLabel lbl = new JLabel("Criterion");
        JPanel p = new JPanel();
        p.add(lbl);
        p.add(box);
        cont.add(p, BorderLayout.NORTH);
        /* List of test sequences */
        suites = new JList();
        suites.setPreferredSize(new Dimension(200, 200));
        JScrollPane sp = new JScrollPane(suites);
        cont.add(sp, BorderLayout.CENTER);
        /* close button */
        JButton but = new JButton("Close");
        but.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TestSuiteFrame.this.setVisible(false);
            }
        });
        p = new JPanel();
        p.add(but);
        cont.add(p, BorderLayout.SOUTH);
        pack();
    }

}